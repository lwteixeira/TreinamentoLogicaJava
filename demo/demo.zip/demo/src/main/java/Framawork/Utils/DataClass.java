package Framawork.Utils;

public class DataClass {

    public static Object[][] loginTestData(){
        return new Object[][] {{"standard_user", "secret_sauce"}};
    }
    
}
