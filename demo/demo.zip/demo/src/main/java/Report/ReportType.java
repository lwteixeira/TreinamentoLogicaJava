package Report;

public enum ReportType {
    SINGLE,
    GROUP;
}
